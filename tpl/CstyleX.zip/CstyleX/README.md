#CstyleX Theme  

The v3 is a ported version of a ported version of the original version, so it is a mess but it works on my special Sentora development VPS.
It does not conform to the new standardization policy of Sentora and NO support will be given for this theme!
I made this ONLY to look if it's still possible to port this theme to Sentora v1.0.0 BETA and it can be done..
The old CDNS manager still works and also has NO support and can be found at: https://github.com/auxio/cdns_manager
(other modifications than cdns_manager are not necessary any more!!..) 
I strongly recommend not using this theme without further development!!!

##Demo
Check this theme out on my [Sentora Demo](http://sentora.ga)

##Description

A cPanel� inspired theme for [Sentora](http://www.sentora.org/).

##Author

This theme is designed by Ron a.k.a. Ron-e [@github](https://github.com/Ron-e) formally know as MathDerVakker [@github](https://github.com/MathDerVakker).

Author's website: [Auxio.eu](http://auxio.eu/)

##WARRANTY

THE THEME IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY. 
IT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE THEME IS WITH YOU. 
SHOULD THE THEME PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW THE AUTHOR WILL BE LIABLE TO YOU FOR DAMAGES, 
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE THEME 
(INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE THEME TO OPERATE WITH ANY OTHER PROGRAMS), 
EVEN IF THE AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
